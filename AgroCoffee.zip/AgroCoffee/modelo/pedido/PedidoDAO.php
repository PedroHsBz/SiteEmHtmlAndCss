<?php
/* ==========================================================================
 *  PedidoDAO.php
 *  Camada: MODELO -> DAO
 *
 *  Operações no banco da tabela pedido.
 *
 *  concluir() usa uma TRANSAÇÃO: baixa o estoque, muda o status e gera a
 *  conta a receber. Se qualquer passo falhar, nada é gravado (rollBack).
 * ========================================================================== */

require_once __DIR__ . "/../ConnectionFactory.php";
require_once __DIR__ . "/Pedido.php";
require_once __DIR__ . "/../produto/ProdutoDAO.php";

class PedidoDAO {

    private $con;

    // SELECT usado nas listagens, já trazendo o nome do cliente e do produto
    private $select = "SELECT p.*, c.nome AS cliente_nome, c.telefone AS cliente_telefone,
                              CONCAT(pr.marca, ' ', pr.modelo) AS produto_nome
                         FROM pedido p
                         JOIN cliente c  ON c.id  = p.cliente_id
                         JOIN produto pr ON pr.id = p.produto_id";

    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    public function cadastrar(Pedido $p) {
        try {
            $stmt = $this->con->prepare(
                "INSERT INTO pedido (cliente_id, produto_id, quantidade, valor, origem)
                 VALUES (:cliente, :produto, :quantidade, :valor, :origem)"
            );
            $stmt->bindValue(":cliente",    $p->getClienteId());
            $stmt->bindValue(":produto",    $p->getProdutoId());
            $stmt->bindValue(":quantidade", $p->getQuantidade());
            $stmt->bindValue(":valor",      $p->getValor());
            $stmt->bindValue(":origem",     $p->getOrigem());
            return $stmt->execute();
        } catch (PDOException $ex) {
            echo "Erro ao cadastrar pedido: " . $ex->getMessage();
            return false;
        }
    }

    // Todos os pedidos (tela do vendedor).
    //   $status: vazio = todos
    //   $busca : texto procurado no nº do pedido, nome do cliente ou produto
    public function listar($status, $busca = "") {
        try {
            $sql = $this->select . " WHERE 1 = 1";
            if ($status != "") {
                $sql .= " AND p.status = :status";
            }
            if ($busca != "") {
                $sql .= " AND CONCAT(p.id, ' ', c.nome, ' ', pr.marca, ' ', pr.modelo) LIKE :busca";
            }
            $sql .= " ORDER BY p.id DESC";

            $stmt = $this->con->prepare($sql);
            if ($status != "") {
                $stmt->bindValue(":status", $status);
            }
            if ($busca != "") {
                $stmt->bindValue(":busca", "%" . $busca . "%");
            }
            $stmt->execute();
            return $this->montarLista($stmt);
        } catch (PDOException $ex) {
            echo "Erro ao listar pedidos: " . $ex->getMessage();
            return array();
        }
    }

    // Pedidos de um cliente ("Meus pedidos" e ficha do cliente)
    public function listarDoCliente($clienteId) {
        try {
            $stmt = $this->con->prepare($this->select . " WHERE p.cliente_id = :id ORDER BY p.id DESC");
            $stmt->bindValue(":id", $clienteId);
            $stmt->execute();
            return $this->montarLista($stmt);
        } catch (PDOException $ex) {
            echo "Erro ao listar pedidos: " . $ex->getMessage();
            return array();
        }
    }

    public function exibir($id) {
        try {
            $stmt = $this->con->prepare($this->select . " WHERE p.id = :id");
            $stmt->bindValue(":id", $id);
            $stmt->execute();
            $linha = $stmt->fetch(PDO::FETCH_ASSOC);
            return $linha ? $this->montar($linha) : null;
        } catch (PDOException $ex) {
            echo "Erro ao exibir pedido: " . $ex->getMessage();
            return null;
        }
    }

    // Só cancela pedido que ainda está Pendente
    public function cancelar($id, $motivo) {
        try {
            $stmt = $this->con->prepare(
                "UPDATE pedido SET status = 'Cancelado', motivo_cancelamento = :motivo
                  WHERE id = :id AND status = 'Pendente'"
            );
            $stmt->bindValue(":motivo", $motivo);
            $stmt->bindValue(":id",     $id);
            $stmt->execute();
            return $stmt->rowCount() > 0;
        } catch (PDOException $ex) {
            echo "Erro ao cancelar pedido: " . $ex->getMessage();
            return false;
        }
    }

    /* -------------------------------------------------------------------
     *  concluir() — devolve null se deu certo, ou a mensagem de erro.
     *    1. baixa o estoque do produto
     *    2. muda o pedido para Concluído
     *    3. gera a conta a receber
     * ------------------------------------------------------------------- */
    public function concluir(Pedido $p, $vencimento) {
        if ($p->getStatus() != "Pendente") {
            return "Só é possível concluir pedidos pendentes.";
        }

        try {
            $this->con->beginTransaction();

            $produtoDAO = new ProdutoDAO();
            $ok = $produtoDAO->movimentar($p->getProdutoId(), "Saída", $p->getQuantidade(), "Venda do pedido #" . $p->getId());
            if (!$ok) {
                $this->con->rollBack();
                return "Estoque insuficiente para concluir o pedido.";
            }

            $stmt = $this->con->prepare("UPDATE pedido SET status = 'Concluído' WHERE id = :id");
            $stmt->bindValue(":id", $p->getId());
            $stmt->execute();

            $stmt = $this->con->prepare(
                "INSERT INTO conta (tipo, descricao, valor, vencimento, pedido_id)
                 VALUES ('Receber', :descricao, :valor, :vencimento, :pedido)"
            );
            $stmt->bindValue(":descricao",  "Venda do pedido #" . $p->getId() . " - " . $p->getClienteNome());
            $stmt->bindValue(":valor",      $p->getValor());
            $stmt->bindValue(":vencimento", $vencimento);
            $stmt->bindValue(":pedido",     $p->getId());
            $stmt->execute();

            $this->con->commit();
            return null;
        } catch (PDOException $ex) {
            $this->con->rollBack();
            return "Erro ao concluir pedido: " . $ex->getMessage();
        }
    }

    private function montarLista($stmt) {
        $lista = array();
        while ($linha = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $lista[] = $this->montar($linha);
        }
        return $lista;
    }

    private function montar($linha) {
        $p = new Pedido();
        $p->setId($linha["id"]);
        $p->setClienteId($linha["cliente_id"]);
        $p->setClienteNome($linha["cliente_nome"]);
        $p->setClienteTelefone($linha["cliente_telefone"]);
        $p->setProdutoId($linha["produto_id"]);
        $p->setProdutoNome($linha["produto_nome"]);
        $p->setQuantidade($linha["quantidade"]);
        $p->setValor($linha["valor"]);
        $p->setOrigem($linha["origem"]);
        $p->setStatus($linha["status"]);
        $p->setMotivoCancelamento($linha["motivo_cancelamento"]);
        $p->setData($linha["data_pedido"]);
        return $p;
    }
}
