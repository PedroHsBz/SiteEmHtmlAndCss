<?php
/* ==========================================================================
 *  Conta.php
 *  Camada: MODELO -> Entidade
 *
 *  tipo  : Pagar | Receber
 *  status: Aberta | Paga
 * ========================================================================== */

class Conta {

    private $id;
    private $tipo;
    private $descricao;
    private $valor;
    private $vencimento;
    private $status;
    private $pagoEm;
    private $pedidoId;
    private $orcamentoId;

    public function getId()                        { return $this->id; }
    public function setId($id)                     { $this->id = $id; }

    public function getTipo()                      { return $this->tipo; }
    public function setTipo($tipo)                 { $this->tipo = $tipo; }

    public function getDescricao()                 { return $this->descricao; }
    public function setDescricao($descricao)       { $this->descricao = $descricao; }

    public function getValor()                     { return $this->valor; }
    public function setValor($valor)               { $this->valor = $valor; }

    public function getVencimento()                { return $this->vencimento; }
    public function setVencimento($vencimento)     { $this->vencimento = $vencimento; }

    public function getStatus()                    { return $this->status; }
    public function setStatus($status)             { $this->status = $status; }

    public function getPagoEm()                    { return $this->pagoEm; }
    public function setPagoEm($pagoEm)             { $this->pagoEm = $pagoEm; }

    public function getPedidoId()                  { return $this->pedidoId; }
    public function setPedidoId($pedidoId)         { $this->pedidoId = $pedidoId; }

    public function getOrcamentoId()               { return $this->orcamentoId; }
    public function setOrcamentoId($orcamentoId)   { $this->orcamentoId = $orcamentoId; }
}
