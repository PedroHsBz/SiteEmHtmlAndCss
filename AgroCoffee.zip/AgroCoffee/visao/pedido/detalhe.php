<?php
/* ============================================================
    detalhe.php
    Camada: VISÃO -> Pedido
    Detalhe do pedido com os botões de concluir e cancelar.
    Espera do CONTROLE: $pedido (Pedido)
   ============================================================ */

// Link do WhatsApp para avisar o cliente (só números no telefone)
$telefone = "55" . preg_replace("/[^0-9]/", "", $pedido->getClienteTelefone());
$texto    = "Olá, " . $pedido->getClienteNome() . "! Seu pedido #" . $pedido->getId() . " na AgroCofee está: " . $pedido->getStatus() . ".";
$whatsapp = "https://wa.me/" . $telefone . "?text=" . urlencode($texto);
?>
<main class="conteudo">
    <h2>Pedido #<?php echo $pedido->getId(); ?></h2>
    <?php require __DIR__ . "/../layout/mensagem.php"; ?>

    <table class="tabela">
        <tr><th>Status</th><td><span class="status <?php echo corStatus($pedido->getStatus()); ?>"><?php echo $pedido->getStatus(); ?></span></td></tr>
        <tr><th>Data</th><td><?php echo date("d/m/Y H:i", strtotime($pedido->getData())); ?></td></tr>
        <tr><th>Origem</th><td><?php echo $pedido->getOrigem(); ?></td></tr>
        <tr><th>Cliente</th><td><?php echo texto($pedido->getClienteNome()); ?></td></tr>
        <tr><th>Telefone</th><td><?php echo texto($pedido->getClienteTelefone()); ?></td></tr>
        <tr><th>Produto</th><td><?php echo texto($pedido->getProdutoNome()); ?></td></tr>
        <tr><th>Quantidade</th><td><?php echo $pedido->getQuantidade(); ?></td></tr>
        <tr><th>Valor</th><td><?php echo dinheiro($pedido->getValor()); ?></td></tr>
        <?php if ($pedido->getStatus() == "Cancelado"): ?>
            <tr><th>Motivo</th><td><?php echo texto($pedido->getMotivoCancelamento()); ?></td></tr>
        <?php endif; ?>
    </table>

    <?php if ($pedido->getStatus() == "Pendente"): ?>
        <div class="acoes">
            <form class="formulario" method="post" action="pedido.php?fun=exibir&id=<?php echo $pedido->getId(); ?>">
                <h3>Concluir venda</h3>
                <p>Baixa o estoque e gera a conta a receber no financeiro.</p>
                <label>Vencimento da conta a receber</label>
                <input type="date" name="vencimento" value="<?php echo date("Y-m-d"); ?>" required>
                <button class="botao" type="submit" name="concluir">Concluir pedido</button>
            </form>

            <form class="formulario" method="post" action="pedido.php?fun=exibir&id=<?php echo $pedido->getId(); ?>">
                <h3>Cancelar</h3>
                <label>Motivo</label>
                <input type="text" name="motivo" required>
                <button class="botao botaoPerigo" type="submit" name="cancelar">Cancelar pedido</button>
            </form>
        </div>
    <?php else: ?>
        <p><a class="botao" href="<?php echo $whatsapp; ?>" target="_blank">Avisar o cliente no WhatsApp</a></p>
    <?php endif; ?>

    <p><a href="pedido.php?fun=listar">Voltar aos pedidos</a></p>
</main>
