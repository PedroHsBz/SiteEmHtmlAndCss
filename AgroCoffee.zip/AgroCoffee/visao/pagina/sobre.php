<?php
/* ============================================================
    sobre.php
    Camada: VISÃO -> Página
    Conteúdo da página Sobre Nós.
   ============================================================ */
?>

    <header class="header">
        <div class="headline">
            <h2 id="txtLSheadLine">Nossa história</h2>
            <h2>Tecnologia para transformar o campo</h2>
            <p>A AgroCofee nasceu para aproximar produtores das melhores soluções agrícolas. Reunimos equipamentos confiáveis, atendimento próximo e conhecimento para ajudar cada cliente a produzir mais.</p>
        </div>
        <div class="img-headline">
            <img class="imgHeadLine" src="assets/img/sobre.jpg" alt="Trator trabalhando no campo">
        </div>
    </header>

    <section>
        <h2>Quem somos</h2>
        <div class="servicos">
            <div class="card">
                <img class="img-card" src="assets/img/sobre1.jpg" alt="Experiência no campo">
                <div class="card-text">
                    <h3>Experiência no campo</h3>
                    <p>Entendemos os desafios de quem trabalha na terra e indicamos máquinas adequadas para cada tipo de produção.</p>
                </div>
                <div class="texto-oculto">
                    <h3>Experiência no campo</h3>
                    <p>Robustez e tecnologia para o seu campo. Orientamos você na escolha dos equipamentos mais adequados para cada tipo de produção.</p>
                </div>
            </div>
            <div class="card">
                <img class="img-card" src="assets/img/sobre2.jpg" alt="Escolhas inteligentes">
                <div class="card-text">
                    <h3>Escolhas inteligentes</h3>
                    <p>Oferecemos tratores e implementos selecionados para entregar produtividade, segurança e economia.</p>
                </div>
                <div class="texto-oculto">
                    <h3>Escolhas inteligentes</h3>
                    <p>Indicamos máquinas e implementos compatíveis com sua operação para melhorar a produtividade, a segurança e a economia no campo.</p>
                </div>
            </div>
            <div class="card">
                <img class="img-card" src="assets/img/sobre3.jpg" alt="Parceria de verdade">
                <div class="card-text">
                    <h3>Parceria de verdade</h3>
                    <p>Nosso relacionamento continua depois da compra, com assistência e suporte para sua operação.</p>
                </div>
                <div class="texto-oculto">
                    <h3>Parceria de verdade</h3>
                    <p>Oferecemos assistência e suporte para ajudar sua operação a continuar produzindo com confiança depois da compra.</p>
                </div>
            </div>
        </div>
    </section>

    <section>
        <h2>Nosso compromisso</h2>
        <div class="headline">
            <p>Trabalhamos para tornar o acesso a equipamentos agrícolas mais simples e transparente. Cada atendimento começa com uma conversa sobre a sua necessidade e termina com uma solução pensada para o seu negócio.</p>
        </div>
    </section>
