<?php
/* ============================================================
    base.php
    Camada: VISÃO -> Layout
    Rodapé usado por TODAS as páginas.
   ============================================================ */
?>
    <footer>
        <div class="logo-rodape">
            <h1 class="agencia">AgroCofee</h1>
            <p>Referência em máquinas agrícolas</p>
        </div>
        <b>© Todos direitos reservados</b>
    </footer>

    <a class="whats" href="https://wa.me/5534999990000" target="_blank"><img src="assets/img/whatsapp.png" alt="WhatsApp"></a>
</body>
</html>
