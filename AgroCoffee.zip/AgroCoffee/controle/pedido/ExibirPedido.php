<?php
/* ==========================================================================
 *  ExibirPedido.php
 *  Camada: CONTROLE
 *
 *  Detalhe do pedido para vendedor e gerente, com os botões:
 *    - Concluir: baixa o estoque e gera a conta a receber (PedidoDAO::concluir)
 *    - Cancelar: precisa informar o motivo
 * ========================================================================== */

require_once __DIR__ . "/../../modelo/pedido/PedidoDAO.php";

class ExibirPedido {

    public function __construct() {

        if (!temAcesso(array("vendedor", "gerente"))) {
            require __DIR__ . "/../../visao/layout/semAcesso.php";
            return;
        }

        $dao    = new PedidoDAO();
        $id     = isset($_GET["id"]) ? $_GET["id"] : 0;
        $pedido = $dao->exibir($id);

        if ($pedido === null) {
            echo "<main class='conteudo'><p class='erro'>Pedido não encontrado.</p></main>";
            return;
        }

        if (isset($_POST["concluir"])) {
            if ($_POST["vencimento"] == "") {
                $erro = "Informe o vencimento da conta a receber.";
            } else {
                $erro = $dao->concluir($pedido, $_POST["vencimento"]);
                if ($erro === null) {
                    $status = "Pedido concluído. Estoque baixado e conta a receber gerada.";
                }
            }
        }

        if (isset($_POST["cancelar"])) {
            if (trim($_POST["motivo"]) == "") {
                $erro = "Informe o motivo do cancelamento.";
            } elseif ($dao->cancelar($id, $_POST["motivo"])) {
                $status = "Pedido cancelado.";
            } else {
                $erro = "Só é possível cancelar pedidos pendentes.";
            }
        }

        $pedido = $dao->exibir($id);   // recarrega com o status novo
        require __DIR__ . "/../../visao/pedido/detalhe.php";
    }
}
